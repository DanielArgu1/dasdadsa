# DEVEX Instrucciones

## Requerimientos

- node.js 18x > LTS
- visual studio code

## Install

Clonar el repositorio y dentro de la carpeta clonada correr:

``` npm install ```

## Running Dev Server

``` npm run dev ```

## Running Build

``` npm run build ```