export default {
    "nav" : [
        {label: 'Inicio', uri: 'index.html'},
        {label: 'Galería', uri: 'gallery.html'},
        {label: 'Catálogo', uri: 'product.html'},
        {label: 'Promoción', uri: 'productos/producto1.html'},
    ]
}