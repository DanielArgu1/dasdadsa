export const getHeroData = ()=>({
    hero: {
        sImgUrl:'https://picsum.photos/id/180/1300/720',
        mImgUrl:'https://picsum.photos/id/180/1024/640',
        lImgUrl:'https://picsum.photos/id/180/1300/720',
        heroTitle:"'Unlock Your Succulents' Full Potential'",
        body: '<p>Our miraculous spray transforms ordinary succulents into vibrant masterpieces.</p><a href="gallery.html" class="button">See the Results</a>'
    }
})