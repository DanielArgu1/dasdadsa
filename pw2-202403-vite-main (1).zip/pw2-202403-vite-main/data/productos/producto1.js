export const getProductData = ()=>({
    hero: {
        sImgUrl:'https://picsum.photos/id/80/1300/720',
        mImgUrl:'https://picsum.photos/id/80/1024/640',
        lImgUrl:'https://picsum.photos/id/80/1300/720',
        heroTitle:"Producto 1 marca ACME",
        body: '<p>Todo lo que necesites para Suculentas, la navaja suiza para cuidados especiales de jardinería</p><a href="../checkout.html" class="button">Comprar Ya</a>'
    }
})